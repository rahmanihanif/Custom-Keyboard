#ifndef NUMPAD_H
#define NUMPAD_H

#ifdef KEYBOARD_numpad_v1
    #include "v1.h"
#endif

#include "quantum.h"


#endif
