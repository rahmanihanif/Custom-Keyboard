HUB Keyboard
===

![Hub Keyboard](../keyboard.png)

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

TODO: Add Description

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Make example for this keyboard (after setting up your build environment):

    make hub_keyboard/v1:default

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
