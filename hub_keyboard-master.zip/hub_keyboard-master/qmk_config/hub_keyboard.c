#include "hub_keyboard.h"

void suspend_power_down_kb(void)
{

}

void suspend_wakeup_init_kb(void)
{

}
