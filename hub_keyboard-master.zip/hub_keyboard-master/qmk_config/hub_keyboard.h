#ifndef HUB_KEYBOARD_H
#define HUB_KEYBOARD_H

#ifdef KEYBOARD_hub_keyboard_v1
    #include "v1.h"
#endif

#include "quantum.h"


#endif
